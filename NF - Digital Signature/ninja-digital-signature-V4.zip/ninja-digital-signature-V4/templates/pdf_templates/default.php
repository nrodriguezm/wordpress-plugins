<?php 
function default_template (){ 
	
	$html = '[vc_row][vc_column width="1/2"][vc_single_image image="17" img_size="160x90"][/vc_column][vc_column width="1/2"][vc_column_text]
	<div style="font-size: 12px !important; line-height: 15px;"><strong>Dirección: Oscar Gestidol 2569, CP 11300 -  Montevideo Uruguay</strong>
	<strong>Tel.: +598 2708 00 00</strong>
	<strong>Email: info@trepcom.com</strong></div>
	[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text]
	<h2>Datos del cliente</h2>
	[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column width="1/4"][vc_column_text]
	<p style="padding: 2px;"><strong>Cliente:</strong></p>
	<p style="padding: 2px;"><strong>Dirección:</strong></p>
	<p style="padding: 2px;"><strong>Email:</strong></p>
	<p style="padding: 2px;"><strong>Celular/Teléfono:</strong></p>
	[/vc_column_text][/vc_column][vc_column width="1/4"][vc_column_text]
	<div style="margin-top: 10px;">
	<p style="border: solid 1px; padding: 1px;">shortcode</p>
	<p style="border: solid 1px; padding: 1px;">shortcode</p>
	<p style="border: solid 1px; padding: 1px;">shortcode</p>
	<p style="border: solid 1px; padding: 1px;">shortcode</p>

	</div>
	[/vc_column_text][/vc_column][vc_column width="1/4"][vc_column_text]
	<p style="padding: 2px 2px 2px 20px; text-align: left;"><strong>Nº de remito:</strong></p>
	<p style="padding: 2px 2px 2px 20px; text-align: left;"><span style="color: #000000;"><strong>Fecha de remito:</strong></span></p>
	<p style="padding: 2px;"><span style="color: #ffffff;"><strong>.</strong></span></p>
	<p style="padding: 2px;"><span style="color: #ffffff;"><strong>.</strong></span></p>
	[/vc_column_text][/vc_column][vc_column width="1/4"][vc_column_text]
	<div style="margin-top: 10px;">
	<p style="border: solid 1px; padding: 1px;">shortcode</p>
	<p style="border: solid 1px; padding: 1px;">shortcode</p>
	<p style="border: solid 1px #ffffff; padding: 1px; color: #ffff;">.</p>
	<p style="border: solid 1px #ffffff; padding: 1px; color: #ffff;">.</p>

	</div>
	[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text]<strong>Descripción del trabajo</strong>[/vc_column_text][vc_column_text]
	<p style="min-height: 80px; height: 80px; text-align: left; border: 1px solid; padding: 2px;">shortcode</p>
	[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text]<strong>Datos del vehículo</strong>[/vc_column_text][vc_column_text]
	<p style="min-height: 80px; height: 80px; text-align: left; border: 1px solid; padding: 2px;">shortcode</p>
	[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column][vc_column_text]

	<hr style="border: solid 2px white;" />

	[/vc_column_text][/vc_column][/vc_row][vc_row][vc_column width="1/2"][vc_row_inner][vc_column_inner width="1/6"][/vc_column_inner][vc_column_inner width="2/3"][vc_column_text]
	<p style="text-align: center; border-bottom: solid 1px;">shortcode</p>
	<p style="text-align: center;"><strong>Firma Cliente</strong></p>
	[/vc_column_text][/vc_column_inner][vc_column_inner width="1/6"][/vc_column_inner][/vc_row_inner][/vc_column][vc_column width="1/2"][vc_row_inner][vc_column_inner width="1/6"][/vc_column_inner][vc_column_inner width="2/3"][vc_column_text]
	<p style="text-align: center; border-bottom: solid 1px;">shortcode</p>
	<p style="text-align: center;"><strong>Firma Técnico</strong></p>
	[/vc_column_text][/vc_column_inner][vc_column_inner width="1/6"][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row][vc_row][vc_column width="1/2"][vc_row_inner][vc_column_inner width="1/6"][/vc_column_inner][vc_column_inner width="2/3"][vc_column_text]
	<p style="text-align: center; border-bottom: solid 1px;">shortcode</p>
	<p style="text-align: center;"><strong>Aclaración</strong></p>
	[/vc_column_text][/vc_column_inner][vc_column_inner width="1/6"][/vc_column_inner][/vc_row_inner][/vc_column][vc_column width="1/2"][vc_row_inner][vc_column_inner width="1/6"][/vc_column_inner][vc_column_inner width="2/3"][vc_column_text]
	<p style="text-align: center; border-bottom: solid 1px;">shortcode</p>
	<p style="text-align: center;"><strong>Aclaración</strong></p>
	[/vc_column_text][/vc_column_inner][vc_column_inner width="1/6"][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]';
	
	return $html;
}
