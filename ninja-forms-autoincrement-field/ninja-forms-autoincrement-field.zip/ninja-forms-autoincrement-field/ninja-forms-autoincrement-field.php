<?php
/*
Plugin Name: Ninja Forms Autoincrement Field
Plugin URI:  https://trepcom.com
Description: Add autoincrement field to a Ninja Form
Version:     3.0
Author:      Andrés Beraldo
Author URI:  https://trepcom.com
*/

define("AU_PLUGIN_DIR", plugin_dir_path( __FILE__ ));

add_filter('ninja_forms_register_fields', 'au_register_autoincrement_field');

function au_register_autoincrement_field($fields){
	
	class Autoincrement extends NF_Abstracts_Input
	{
		protected $_name = 'autoincrement';

		protected $_section = 'misc';
		
		protected $_icon = 'arrow-circle-up';
		
		protected $_aliases = array( 'input' );

		protected $_type = 'autoincrement';

		protected $_templates = 'autoincrement';

		protected $_settings_only = array(
			'key', 'label', 'admin_label'
		);

		protected $_use_merge_tags_include = array( 'calculations' );

		public function __construct()
		{
			parent::__construct();

			$use_merge_tags = array( 'include' => array( 'calculations' ) );

			$this->_settings[ 'autoincrement' ] = array(
				'name' => 'autoincrement',
				'type' => 'number',
				'label' => __( 'Increment number since', 'ninja-forms'),
				'width' => 'one-third',
				'group' => 'primary',
				'value' => '',
			);

			$this->_nicename = __( 'Autoincrement', 'ninja-forms' );
			add_filter('ninja_forms_field_template_file_paths', array( $this, 'add_custom_template_path' ));
		}
		
		public function add_custom_template_path($templates){
			$templates[] = AU_PLUGIN_DIR . '/templates/';
			return $templates;
		}
	}
	
	$fields['autoincrement'] = new Autoincrement;

	return $fields;
}

add_filter( 'ninja_forms_render_default_value', 'au_default_value', 10, 3 );
function au_default_value( $default_value, $field_type, $field_settings ) {
  if( 'autoincrement' == $field_type ){
    $default_value = $field_settings['autoincrement'];
  }
  return $default_value;
}
	 
add_action( 'ninja_forms_after_submission', 'au_increment_value' );
function au_increment_value( $form_data ){
	 
	$form_id = (int) $form_data['form_id'];

	// Bust the cache.
	delete_option( 'nf_form_'. $form_data['form_id']); 
	 
	foreach( $form_data['fields'] as $field ){
		
		if($field['type']=="autoincrement"){
			$field_id = (int)$field["id"];
		
			$model = Ninja_Forms()->form($form_id)->field( $field_id )->get();
		
			$setting = $model->get_setting( 'autoincrement' );
			
			$value = (int)$setting + 1;
			
			$model->update_setting( 'autoincrement', "$value" )->save();
		}

	}
	
}


?>