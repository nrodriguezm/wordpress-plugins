Requirements 
==========================

   -- Ninja Forms plugin installed.
   -- Google form created.


Install
==========================

   -- Download "ninja_to_drive.zip"
   -- Install the plugin in Plugins/Add New
   -- Upload the .zip file and activate the plugin.

Usage
==========================

   -- When you edit/create a form, "Google Drive" tab appears.
   -- There you have this options:
	--> "Enable Google drive submition": Is for enabling submissions.
	--> "Url form drive": The Url of the google form. Format is:  https://docs.google.com/forms/d/xxxxxxxxxx
	--> "Fields ID": For each form field, a new field is created with an input in which you have to fill with the google form field id.
	--> "Email adress": Specify here an email for reporting errors in submissions. There are two tipe of errors. Wrong "Url form drive" specified, or "Allow only one answer per person (login required)" option is activated in google form. 

	 


Requisitos
==========================

   -- Tener instalado el plugin Ninja Forms.
   -- Crear un formulario en google drive.


Instalacion
==========================

   -- Descargar "ninja_to_drive.zip"
   -- Instalar el plugin en Plugins/A�adir Nuevo
   -- Subir el archivo .zip y activar el plugin.

Modo de uso
==========================

   -- En la secci�n de edici�n/creaci�n de un formulario de ninja forms, se crea una nueva pesta�a "Google Drive".
   -- All� aparecen las siguientes opciones:
	--> "Enable Google drive submition": Es para activar el registro en planilla.
	--> "Url form drive": Url del fomrulario de google. El formato debe ser  https://docs.google.com/forms/d/xxxxxxxxxx
	--> "Fields ID": Para cada campo del formulario, se crea un campo donde se debe rellenar con el id del campo correspondiente del formulario de google.
	--> "Email adress": Aqu� se debe ingresar un email para notificaci�n en caso de error. Existen dos tipos de errores: "Url form drive" es erronea, o la opcion Permitir solo una respuesta por persona (es necesario iniciar sesi�n) est� activada en el formulario de google.